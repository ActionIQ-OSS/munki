<?php

return array(
    'client_tabs' => array(
        'firmware-tab' => array('view' => 'firmware_tab', 'i18n' => 'firmware_escrow.title'),
    ),

    'listings' => array(
        'firmware' => array('view' => 'firmware_listing', 'i18n' => 'firmware_escrow.title'),
    ),
);
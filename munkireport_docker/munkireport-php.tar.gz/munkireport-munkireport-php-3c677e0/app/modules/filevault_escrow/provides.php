<?php

return array(
    'client_tabs' => array(
        'filevault-tab' => array('view' => 'filevault_tab', 'i18n' => 'filevault_escrow.fv_escrow'),
    ),
);

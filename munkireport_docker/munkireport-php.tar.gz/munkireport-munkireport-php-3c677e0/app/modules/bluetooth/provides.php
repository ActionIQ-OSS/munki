<?php

return array(
    'listings' => array(
        'bluetooth' => array('view' => 'bluetooth_listing', 'i18n' => 'bluetooth.title'),
    ),
    'widgets' => array(
        'bluetooth_battery' => array('view' => 'bluetooth_battery_widget'),
    ),
);

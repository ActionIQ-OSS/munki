DeployStudio module
==============

Provides DeployStudio details about the client if it exists in the DeployStudio database.

The client listing table provides the following information:
* Last workflow executed by the client.
* Date the last workflow was run
* Duration of last workflow
* Status of last workflow

The DeployStudio tab will show a number of important computer configurations set in DeployStudio
*  Computer ARD fields

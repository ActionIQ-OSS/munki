#!/bin/bash

# Remove warranty script
rm -f "${MUNKIPATH}preflight.d/deploystudio"

# Remove deploystudio.txt file
rm -f "${CACHEPATH}deploystudio.txt"

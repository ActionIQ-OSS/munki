#!/bin/bash

# Remove homebrew_info script
rm -f "${MUNKIPATH}preflight.d/homebrew_info.sh"

# Remove homebrew_info.json file
rm -f "${CACHEPATH}homebrew_info.json"

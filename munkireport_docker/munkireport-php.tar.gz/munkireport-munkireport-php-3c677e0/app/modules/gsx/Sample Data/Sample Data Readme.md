Sample data provided by tuxedo from live environment. Serial numbers have been edited. 

.sql file can generate gsx table within MySQL, may work in SQLite.
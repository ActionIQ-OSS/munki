<?php

return array(
    'client_tabs' => array(
        'gsx-tab' => array('view' => 'gsx_tab', 'i18n' => 'gsx.title'),
    ),
    'listings' => array(
        'gsx' => array('view' => 'gsx_listing', 'i18n' => 'gsx.title'),
    ),
    'widgets' => array(
        'support_status_gsx' => array('view' => 'support_status_gsx_widget'),
    ),
);

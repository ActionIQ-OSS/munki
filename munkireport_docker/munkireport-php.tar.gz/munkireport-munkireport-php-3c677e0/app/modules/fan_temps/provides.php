<?php

return array(
    'client_tabs' => array(
        'fan_temps-tab' => array('view' => 'fan_temps_tab', 'i18n' => 'fan_temps.tabtitle'),
    ),
    'listings' => array(
        'fan_temps' => array('view' => 'fan_temps_listing', 'i18n' => 'fan_temps.tabtitle'),
    ),
);

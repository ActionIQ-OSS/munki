<?php

return array(
    'listings' => array(
        'findmymac' => array('view' => 'findmymac_listing', 'i18n' => 'findmymac.title'),
    ),
    'widgets' => array(
        'findmymac' => array('view' => 'findmymac_widget'),
    ),
);

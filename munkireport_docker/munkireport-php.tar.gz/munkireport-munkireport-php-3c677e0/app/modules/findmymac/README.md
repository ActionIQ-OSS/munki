FindMyMac module
======
Reports on FindMyMac status. These values are being pulled from `nvram` so this script will determine the correct status even if a machine was reimaged.

This module displays the following data:

* Status - If FindMyMac is enabled/disabled
* Email - The email account associated with FindMyMac
* OwnerDisplayName - The Owner's Display Name of the associated email account
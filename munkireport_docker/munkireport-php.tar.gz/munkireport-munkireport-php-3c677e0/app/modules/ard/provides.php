<?php

return array(
    'listings' => array(
        'ard' => array('view' => 'ard_listing', 'i18n' => 'ard.ard'),
    ),
);

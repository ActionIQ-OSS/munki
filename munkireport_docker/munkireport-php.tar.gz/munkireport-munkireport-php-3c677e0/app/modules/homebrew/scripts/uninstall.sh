#!/bin/bash

# Remove homebrew script
rm -f "${MUNKIPATH}preflight.d/homebrew.sh"

# Remove homebrew.json file
rm -f "${CACHEPATH}homebrew.json"

#!/bin/bash

rm -f "${MUNKIPATH}preflight.d/crashplan"
rm -f "${CACHEPATH}crashplan.txt"


<?php

return array(
    'listings' => array(
        'crashplan' => array('view' => 'crashplan_listing', 'i18n' => 'crashplan.title'),
    ),
    'widgets' => array(
        'crashplan' => array('view' => 'crashplan_widget'),
    ),
);

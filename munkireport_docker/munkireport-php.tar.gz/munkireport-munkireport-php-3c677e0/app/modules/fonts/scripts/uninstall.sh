#!/bin/bash

# Remove fonts script
rm -f "${MUNKIPATH}preflight.d/fonts.py"

# Remove fonts.plist file
rm -f "${CACHEPATH}fonts.plist"

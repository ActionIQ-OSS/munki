<?php

return array(
    'client_tabs' => array(
        'fonts-tab' => array('view' => 'fonts_tab', 'i18n' => 'fonts.clienttab', 'badge' => 'fonts-cnt'),
    ),
    'listings' => array(
        'fonts' => array('view' => 'fonts_listing', 'i18n' => 'fonts.clienttab'),
    ),
    'widgets' => array(
       'fonts' => array('view' => 'fonts_widget'),
    ),
);

<?php

return array(
    'client_tabs' => array(
        'gpu-tab' => array('view' => 'gpu_tab', 'i18n' => 'gpu.clienttab'),
    ),
    'listings' => array(
        'gpu' => array('view' => 'gpu_listing', 'i18n' => 'gpu.clienttab'),
    ),
    'widgets' => array(
        'gpu_model' => array('view' => 'gpu_model_widget'),
    ),
);

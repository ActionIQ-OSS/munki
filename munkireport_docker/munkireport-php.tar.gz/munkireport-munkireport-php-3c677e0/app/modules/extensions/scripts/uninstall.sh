#!/bin/bash

# Remove extensions script
rm -f "${MUNKIPATH}preflight.d/extensions.py"

# Remove extensions.plist file
rm -f "${CACHEPATH}extensions.plist"

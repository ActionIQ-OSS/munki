<?php

return array(
    'listings' => array(
        'localadmin' => array('view' => 'localadmin', 'i18n' => 'localadmin.localadmin',),
    ),
    'widgets' => array(
        'localadmin' => array('view' => 'localadmin_widget'),
    ),
    'reports' => array(
        'localadmin' => array('view' => 'localadmin_report', 'i18n' => 'localadmin.localadmin',),
    ),
);



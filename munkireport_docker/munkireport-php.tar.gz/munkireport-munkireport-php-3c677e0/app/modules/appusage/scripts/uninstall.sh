#!/bin/bash

rm -f "${MUNKIPATH}preflight.d/appusage"
rm -f "${CACHEPATH}appusage.csv"

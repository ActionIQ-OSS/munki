<?php

return array(
    'client_tabs' => array(
        'homebrew_info-tab' => array('view' => 'homebrew_info_tab', 'i18n' => 'homebrew_info.clienttitle'),
    ),
    'listings' => array(
        'homebrew_info' => array('view' => 'homebrew_info_listing', 'i18n' => 'homebrew_info.clienttitle'),
    ),
);
<?php

return array(
    'client_tabs' => array(
        'homebrew-tab' => array('view' => 'homebrew_tab', 'i18n' => 'homebrew.clienttitle', 'badge' => 'homebrew-cnt'),
    ),
    'listings' => array(
        'homebrew' => array('view' => 'hbrew_listing', 'i18n' => 'homebrew.clienttitle'),
    ),
);

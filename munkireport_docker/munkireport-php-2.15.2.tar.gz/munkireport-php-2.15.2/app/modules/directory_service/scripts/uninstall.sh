#!/bin/bash

# Remove directoryservice script
rm -f "${MUNKIPATH}preflight.d/directoryservice.sh"

# Remove directoryservice.txt
rm -f "${CACHEPATH}directoryservice.txt"


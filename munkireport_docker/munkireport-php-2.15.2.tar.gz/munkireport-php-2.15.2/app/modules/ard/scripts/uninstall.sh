#!/bin/bash

rm -f "${MUNKIPATH}preflight.d/init_ard"

<?php

return array(
    'listings' => array(
        'munkiinfo' => array('view' => 'munkiinfo_listing', 'i18n' => 'munkiinfo.listing'),
    ),
    'widgets' => array(
        'munkiinfo_munkiprotocol' => array('view' => 'munkiinfo_munkiprotocol_widget'),
    ),
);
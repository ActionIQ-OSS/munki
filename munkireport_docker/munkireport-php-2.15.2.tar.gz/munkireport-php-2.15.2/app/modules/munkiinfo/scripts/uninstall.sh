#!/bin/bash

rm -f "${MUNKIPATH}preflight.d/munkiinfo.py"
rm -f "${CACHEPATH}munkiinfo.plist"


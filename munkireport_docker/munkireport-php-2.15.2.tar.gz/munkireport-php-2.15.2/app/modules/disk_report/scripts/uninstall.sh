#!/bin/bash

# Remove disk_info script
rm -f "${MUNKIPATH}preflight.d/disk_info"

# Remove disk.plist
rm -f "${CACHEPATH}disk.plist"


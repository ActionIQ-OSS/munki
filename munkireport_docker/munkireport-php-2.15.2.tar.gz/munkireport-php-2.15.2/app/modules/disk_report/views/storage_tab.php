<div id="storage-plot"></div>

<script>
$(document).on('appReady', function(e, lang) {
    drawStoragePlots(serialNumber, 'storage-plot');
});
</script>

#!/bin/bash

# Remove gsx script
rm -f "${MUNKIPATH}preflight.d/gsx"

# Remove gsx.txt file
rm -f "${CACHEPATH}gsx.txt"

Bluetooth module
==============

Provides Bluetooth status and uses ioreg to report on battery levels.

Data can be viewed under the Bluetooth tab on the client details page or using the Bluetooth list view 


* Is Bluetooth on or off
* Battery life remaining for Keyboard
* Battery life remaining for Mouse
* Battery life remaining for Trackpad


To do
---

* Build a report showing battery levels under 15%

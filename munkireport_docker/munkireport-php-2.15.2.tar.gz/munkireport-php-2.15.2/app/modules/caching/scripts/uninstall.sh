#!/bin/bash

rm -f "${MUNKIPATH}preflight.d/caching"
rm -f "${CACHEPATH}caching.txt"


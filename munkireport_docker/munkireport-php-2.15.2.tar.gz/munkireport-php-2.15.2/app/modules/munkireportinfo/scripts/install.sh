#!/bin/bash

# Set preference to include this file in the preflight check
setreportpref "munkireportinfo" "/Library/Preferences/MunkiReport.plist"

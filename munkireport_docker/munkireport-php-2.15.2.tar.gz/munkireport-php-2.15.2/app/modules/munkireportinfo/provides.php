<?php

return array(
    'client_tabs' => array(
        'munkireportinfo-tab' => array('view' => 'munkireportinfo_tab', 'i18n' => 'munkireportinfo.clienttabtitle'),
    ),
    'listings' => array(
        'mrinfo' => array('view' => 'mrinfo_listing', 'i18n' => 'munkireportinfo.clienttabtitle'),
    ),
);

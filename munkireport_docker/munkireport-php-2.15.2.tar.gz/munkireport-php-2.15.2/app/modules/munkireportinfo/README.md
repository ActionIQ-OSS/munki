MunkiReport reporting module
==============

Reports on the MunkiReport on the client

* version - int - version of MunkiReport installed
* baseurl - varchar(255) - URL of the MunkiReport instance
* passphrase - varchar(255) - Passphrased used by client
* reportitems - varchar(1024) - list of installed modules

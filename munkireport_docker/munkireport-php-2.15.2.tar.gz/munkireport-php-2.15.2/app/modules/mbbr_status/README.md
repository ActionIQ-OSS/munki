Malwarebytes Module
==============

Provides activation information for clients using Malwarebytes Breach Remediation's CLI tool, MBBR

The client listing table provides the following information:
* Entitlement (Licensed) status of client
* The client's Malwarebytes Machine ID as listed in the MBBR Admin Console
* The client's installation token for Malwarebytes

The Malwarebytes Status tab will show this same information.

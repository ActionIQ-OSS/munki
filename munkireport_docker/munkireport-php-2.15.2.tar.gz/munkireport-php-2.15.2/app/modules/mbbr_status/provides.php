<?php

return array(
    'client_tabs' => array(
        'mbbr_status-tab' => array('view' => 'mbbr_status_tab', 'i18n' => 'mbbr_status.clienttab'),
    ),
    'listings' => array(
        'mbbr_status' => array('view' => 'mbbr_status_listing', 'i18n' => 'mbbr_status.clienttab'),
    ),
);

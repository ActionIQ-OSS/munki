#!/bin/bash

# Remove filevaultstatus script
rm -f "${MUNKIPATH}preflight.d/filevaultstatus"

# Remove the filevaultstatus.txt cache file
rm -f "${CACHEPATH}filevaultstatus.txt"


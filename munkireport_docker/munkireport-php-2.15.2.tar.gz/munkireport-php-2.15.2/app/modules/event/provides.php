<?php

return array(
    'widgets' => array(
        'messages' => array('view' => 'messages_widget'),
    ),
);

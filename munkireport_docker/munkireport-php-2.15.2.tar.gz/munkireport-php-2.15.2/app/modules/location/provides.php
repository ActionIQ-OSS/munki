<?php

return array(
    'client_tabs' => array(
        'location-tab' => array('view' => 'location_tab', 'i18n' => 'location.location'),
    ),
    'listings' => array(
        'location' => array('view' => 'location_listing', 'i18n' => 'location.location'),
    ),
    'reports' => array(
        'location' => array('view' => 'location', 'i18n' => 'location.report'),
    ),
);

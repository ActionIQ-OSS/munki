#!/bin/bash

# Nothing to remove as this module is now dependent on https://github.com/clburlison/pinpoint

#!/bin/bash

# Remove findmymac_manfiest script
rm -f "${MUNKIPATH}preflight.d/findmymac.sh"

# Remove findmymacinfo.txt file
rm -f "${MUNKIPATH}preflight.d/cache/findmymac.txt"

#!/bin/bash

# Remove backup2go script
rm -f "${MUNKIPATH}preflight.d/backup2go.sh"

# Remove backup2go.txt file
rm -f "${MUNKIPATH}preflight.d/cache/backup2go.txt"

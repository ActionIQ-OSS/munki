<?php

return array(
    'listings' => array(
        'backup2go' => array('view' => 'backup2go_listing', 'i18n' => 'backup2go.listing_title'),
    ),
    'widgets' => array(
        'backup2go' => array('view' => 'backup2go_widget'),
    ),
);

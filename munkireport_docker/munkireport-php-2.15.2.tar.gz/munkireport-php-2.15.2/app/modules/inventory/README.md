Inventory module
================

Gathers inventory information found in `/Library/Managed Installs/ApplicationInventory.plist`

The table provides the following information per 'item':

* id (int) Unique id
* serial_number (string) Serial Number
* name (string) Name
* version (string) Version
* bundleid (string) Bundle ID
* bundlename (string) Bundle Name
* path (string) Path


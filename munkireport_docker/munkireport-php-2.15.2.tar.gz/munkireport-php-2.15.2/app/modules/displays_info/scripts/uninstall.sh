#!/bin/bash

# Remove directoryservice script
rm -f "${MUNKIPATH}preflight.d/displays.py"

# Remove directoryservice.txt
rm -f "${CACHEPATH}displays.txt"

<?php

return array(
    'client_tabs' => array(
        'deploystudio-tab' => array('view' => 'deploystudio_tab', 'i18n' => 'deploystudio.title'),
    ),
    'listings' => array(
        'deploystudio' => array('view' => 'deploystudio_listing', 'i18n' => 'deploystudio.title'),
    ),
);
